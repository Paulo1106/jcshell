/*
	// jc-shell - exercicio 1, version 1
	// Sistemas Operativos, DEI-CC/FC/UAN 2020

								GRUPO Nº 10
							
							===== ELEMENTOS DO GRUPO =====

							1º PAULO KANTUKU DA CRUZ --------   https://github.com/Paulo1106
							2º ROSÁRIO QUINTAS       --------
							3º ALBERTO FRANCISCO     --------
*/

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <time.h>
#include "lista.h"

#include "commandlinereader.h"

#define EXIT_COMMAND "exit"
#define MAXARGS 7
#define STATUS_INFO_LINE_SIZE 50
#define BUFFER_SIZE 100

// VARIÁVEL GLOBAL

int numchildren;         //GUARDA O Nº DE PROCESSOS FILHOS CRIADOS


LISTA_TAREFA *lista_de_processos; //GUARDA AS INFORMAÇÕES DOS PROCESSOS LANÇADOS

pthread_mutex_t lista_de_processos_mtx = PTHREAD_MUTEX_INITIALIZER;

pthread_mutex_t numchildren_mtx = PTHREAD_MUTEX_INITIALIZER;



// MONITORIZAÇÃO DE PROCESSOS

void* monitorarProcessos(){
      
      int status, childpid;
      
      do{
		  sleep(7);
		  listar(lista_de_processos);
		  
		  if(numchildren > 0){
			childpid = wait(&status);

			if(childpid < 0){
			  if(errno == EINTR){
				continue;
			  }else{
				perror("Error waiting for child.");
				exit(EXIT_FAILURE);
			  }
			}
			numchildren--;
		  }else{
			  sleep(1);
			  continue;
		  }
      }while(1);
	return NULL;
}


  int main (int argc, char **argv) {
	
  //mostrar();

  lista_de_processos = criar(); // FUNÇÃO PARA A CRIAÇÃO DA LISTA DE PROCESSOS

  numchildren = 0;
  
  char *args[MAXARGS];

  char buffer[BUFFER_SIZE];

  //CRIAÇÃO DE THREAD PARA MONITORIZAR O PROCESSO

  pthread_t idt_monitora;
  
  int resposta = pthread_create(&idt_monitora,NULL,monitorar_processos,NULL); 
  
  if (resposta != 0) {
 	 perror("Thread creation failed");
	 exit(EXIT_FAILURE);
  }
   
 //PRINÇÍPIO DO LANÇAMENTO DOS PROCESSOS
 
  printf("Insert your commands:\n");

  while (1){
    
    int numargs;

    numargs = readLineArguments(args, MAXARGS, buffer, BUFFER_SIZE);

    if (numargs < 0 || (numargs > 0 && (strcmp(args[0], EXIT_COMMAND) == 0))){
      
	  int status, childpid;
      int message_size = numchildren * STATUS_INFO_LINE_SIZE;

      char *childstatusmessage = NULL;
      char aux[STATUS_INFO_LINE_SIZE];

      if (numchildren > 0){
        childstatusmessage = (char *)malloc(message_size);
        childstatusmessage[0] = '\0';
      }

      while(numchildren > 0){
			childpid = wait(&status);

			if(childpid < 0){
			  if(errno == EINTR){
				continue;
			  }else{
				perror("Error waiting for child.");
				exit(EXIT_FAILURE);
			  }
			}

			if (WIFEXITED(status))
			  snprintf(aux, sizeof(aux), "pid: %d exited normally; status = %d\n",
					   childpid, WEXITSTATUS(status));
			else
			  snprintf(aux, sizeof(aux), "pid: %d terminated without calling exit\n",
					   childpid);
			strncat(childstatusmessage, aux, message_size);
			
			numchildren--;
      }

      if(childstatusmessage != NULL)
        printf("%s", childstatusmessage);
      exit(EXIT_SUCCESS);
    }else if (numargs > 0){
      int pid = fork();

      if (pid < 0){
        perror("Failed to create new process.");
        exit(EXIT_FAILURE);
      }

      if (pid > 0){
        numchildren++;
		
		//INSERIR AS INFORMAÇÕES DO PROCESSO ENVIADO NA LISTA
		
		inserir(lista_de_processos,pid,time(NULL), time(NULL));
        continue;
      }else{
        if (execv(args[0], args) < 0){
          perror("Could not run child program. Child will exit.");
          exit(EXIT_FAILURE);
        }
      }
    }
  }   // TÉRMINO DO LANÇAMENTO DE PROCESSO
 
 
  //AGUARDA PELO TÉRMINO DA THREAD MONITORA
 
  pthread_join(idt_monitora,NULL);
}
