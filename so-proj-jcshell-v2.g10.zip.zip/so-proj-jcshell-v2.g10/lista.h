#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct no {
    time_t tempoInicio;
    time_t tempoFim;
    int pid;
    struct no *prox;
}NO;

typedef struct listaDeTarefas {
    NO *cabeca;
}LISTA_TAREFA;


LISTA_TAREFA* criar();

int inserir(LISTA_TAREFA *lista, int pid, time_t inicio, time_t fim);

void update_terminated_process (LISTA_TAREFA *lista, int pid, time_t fim);

void listar(LISTA_TAREFA *lista);

void mostrar();

void destruir(LISTA_TAREFA *lista);




