#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "lista.h"


LISTA_TAREFA* criar(){
    LISTA_TAREFA *lista;
    lista = (LISTA_TAREFA*) malloc(sizeof(LISTA_TAREFA));
    lista->cabeca = NULL;
    return lista;
}

/*
int isVazia(LISTA_TAREFA lista){
    if(lista.cabeca == NULL)
        return 1;
    return 0;
}
*/


int inserir(LISTA_TAREFA *lista, int pid, time_t inicio, time_t fim){
    NO *novo_no = (NO*) malloc(sizeof(NO));
    novo_no->pid = pid;
    novo_no->tempoInicio = inicio;
    novo_no->tempoFim = fim;
    if(lista->cabeca == NULL){
        novo_no->prox = NULL;
        lista->cabeca = novo_no;
        return 1;
    }else{
        novo_no->prox = lista->cabeca;
        lista->cabeca = novo_no;
        return 1;
    }
    return 0;
}

void update_terminated_process (LISTA_TAREFA *lista, int pid, time_t fim) {
	NO *aux = lista->cabeca;
	while(aux != NULL) {
		if(aux->pid == pid) {
			aux->tempoFim = fim;
			break;
		}
		aux = aux->prox;
	}	
}


void listar(LISTA_TAREFA *lista){
    NO *aux = lista->cabeca;
    while(aux != NULL){
        printf(" PID: %d \n", aux->pid);
        printf(" TEMPO IN�CIO: %li \n", aux->tempoInicio);
        printf(" TEMPO FIM: %li \n", aux->tempoFim);
        aux = aux->prox;
    }
}


void destruir(LISTA_TAREFA *lista){
    NO *aux = lista->cabeca;
    while(aux != NULL){
        aux = aux->prox;
	free(aux->prox);
    }
}



